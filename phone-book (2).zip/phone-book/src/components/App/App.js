
/*****************************************
 * * IMPORT LIBRARIES
 *****************************************/

// react libraries
import React from 'react';

// import components
import Header from '../header/Header';
import MainContent from '../main/Main'; // we can rename what was defined with default export
import Footer from '../footer/Footer';

/*****************************************
* * COMPONENT
*****************************************/

const App = () => {
  const date = new Date();
  return (
    <div className="app">
      <Header text="Phone Book"/>
      <MainContent />
      <Footer year={date.getFullYear()} name="Issa Oday"/>
    </div>
  );
}

export default App;
 