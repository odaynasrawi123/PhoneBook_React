import React, { Component } from 'react'
import ContactItem from '../ListItems/ContactItem';
import DataManager from '../../Scripts/DataManagement'
import InnerAlert from '../Alerts/InnerAlert'

class ContactsList extends React.Component {

    constructor(props) {
        super(props);

        DataManager.dataEdited = this.forceUpdate.bind(this);
    }

    //Delete item
    itemDeleteClick(id) {
        DataManager.removeContact(id);
        this.forceUpdate();
    }

    //Returns all contacts that is supposed to apeare in list
    getContacts() {
        var data = [];
        var searchTxt = this.props.filterString;
        //Adds contacts to data array by search value
        DataManager.contacts.forEach(item => {
            if(item.name.toLowerCase().includes(searchTxt.toLowerCase())) data.push(item);
        });

        //Sort by name
        data.sort((a, b) => a.name.localeCompare(b.name));

        /*=====update parent about number of contacts=====*/
        this.props.onChange(data.length);
        /*================================================*/

        if(data.length === 0) {
            return <InnerAlert />;
        }

        /*======Create elements======*/
        const contactComponents = [];
        // console.log(DataManager.contacts);
        data.forEach(item => {
            //Add editClick prop
            contactComponents.push(
                <ContactItem details={ item }
                    onEditClick={ this.props.itemEditClick }
                    viewBtnClick={ this.props.itemViewClick }
                    deleteBtnClick={ this.itemDeleteClick.bind(this) } />
            );
        });

        return contactComponents;
    }

    render() {
        return (
            <div id="contactsListView" className="list_view">
                {/*Contacts gets filled here*/}
                { this.getContacts() }
            </div>
        );
    }

}

export default ContactsList;