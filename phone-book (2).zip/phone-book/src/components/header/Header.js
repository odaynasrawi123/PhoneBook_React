import React from 'react';

const Header = (props) => {
  return (
    <header className="main-heading">
      <h1>{props.text}</h1>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
    </header>
  );
};

export default Header;
