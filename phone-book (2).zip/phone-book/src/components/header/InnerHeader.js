import React from 'react';
import '../../styles/TopBar.css';

const InnerHeader = (props) => {

  const search = (event) => {
    props.onSearch(event.target.value);
  };

  return (
    <div className="columns_layout">
        {/*Search column*/}
        <div className="c1">
          <div className="search-field">
            <input type="text" placeholder="Search" onChange={ search } />
            <i className="fa fa-search"></i>
          </div>
        </div>
        {/*top bar buttons*/}
        <div>
            <button className="btn" onClick={ props.addBtnClick }><i className="fa fa-plus" aria-hidden="true"></i></button>
            <button className="btn" onClick={ props.deleteAllBtnClick }><i className="fa fa-trash-o" aria-hidden="true"></i></button>
            <button className="btn" onClick={ props.saveBtnClick }><i className="fa fa-floppy-o" aria-hidden="true"></i></button>
        </div>
    </div>
  );
};

export default InnerHeader;