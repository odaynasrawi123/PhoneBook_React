import React from 'react';

const Footer = props => {
  return (
    <footer>
      {/* inside {} we write JavaScript */}
      &copy; {props.year} {props.name}
    </footer>
  );
};

export default Footer;
