import React from 'react'

class TextField extends React.Component {

    constructor(props) {
        super(props);

        this.state = { "value": props.value };
    }

    //validated = false;
    validate(value) {
        //this.validated = true;

        //If is empty
        if(value === "") {
            //Not valid if empty and required
            if(this.props.required) {
                this.setState({ validationMessage: "field is required" });
                return false;
            } else {
                this.setState({ validationMessage: "" });
                return true;
            }
        }
        
        let reg = new RegExp(this.props.reg);

        //Tests regular expretion on string value
        const valid = reg.test(value);

        if(valid) {
            this.setState({ validationMessage: "" });
            return true;
        } else {
            this.setState({ validationMessage: this.props.invalidMes });
            return false;
        }
    }

    //Handles input value change
    handleChange(event) {
        //Data changed without validation
        //this.validated = false;
        this.setState({ value: event.target.value });
        const valid = this.validate(event.target.value);
        this.props.onChange(event, valid);
    }
    
    //Gets called whenever props or state are about to be updated
    shouldComponentUpdate(nextProps, nextState) {
        //If forceValidation is about to be updated from false to true
        if(!this.props.forceValidation && nextProps.forceValidation) {
            //Then validate
            const valid = this.validate(nextState.value);
            const event = { target: { name: this.props.name, value: nextState.value, type: "TextField"} };
            this.props.onChange(event, valid);
        }
        return true;
    }

    render() {
        return (
            <div className="columns_layout">
                <label>{ this.props.title }{ this.props.required ? "*" : "" }</label>
                <span className="c1">
                    <input name={ this.props.name } type="text" value={ this.state.value } onChange={ this.handleChange.bind(this) } placeholder={ this.props.title.toLowerCase() } />
                    {/*Validation message*/}
                    <div className="validation-message">{ this.state.validationMessage }</div>
                </span>
            </div>
        );
    }

}

export default TextField;