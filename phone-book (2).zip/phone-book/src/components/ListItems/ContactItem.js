import React from 'react';

import '../../styles/ContactItem.css';

class ContactItem extends React.Component {

    state = {
        imageError: false  // Will be true if image url is invalid
    };

    //Call Edit
    edit(event) {
        this.props.onEditClick(this.props.details.id);
        event.stopPropagation();
        event.preventDefault();
    }

    //Call add
    remove(event) {
        this.props.deleteBtnClick(this.props.details.id);
        event.stopPropagation();
        event.preventDefault();
    }

    //Call view
    viewBtnClick() {
        this.props.viewBtnClick(this.props.details.id);
    }

    //To load default image
    handleImgError() {
        this.setState({ "imageError": true });
    }

    render() {
        return (
            <div id={"contact" + this.props.details.id} className="list_item">
                <div className="imageContainer">
                    <img src={ this.state.imageError ? "https://th.bing.com/th/id/R.62a9c55bd61bd7879a727a5c991daf42?rik=Mj1nm%2fDT%2bkMyHQ&pid=ImgRaw" : this.props.details.imgUrl } alt="Contact" onError={ this.handleImgError.bind(this) } />
                </div>
                <p>{ this.props.details.name }</p>
                <p>{ this.props.details.phone }</p>
                <p className="fill">
                    <button onClick={ this.viewBtnClick.bind(this) } className="btn"><i className="fa fa-info" aria-hidden="true"></i></button>
                    <button onClick={ this.edit.bind(this) } className="btn"><i className="fa fa-pencil-square-o" aria-hidden="true"></i></button>
                    <button onClick={ this.remove.bind(this) } className="btn"><i className="fa fa-trash-o" aria-hidden="true"></i></button>
                </p>
            </div>
        );
    }
    
}

// in case some field is not sent to props,
// it will take the value from defaultProps
ContactItem.defaultProps = {
      name: 'Contact',
      phone: '050-0000000',
      id: 3
};

export default ContactItem;