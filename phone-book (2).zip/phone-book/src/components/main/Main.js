import React from 'react';
import InnerHeader from '../header/InnerHeader';
import ContactsList from '../PlaceHolder/ContactsList';
import ContactAddPopup from '../Popups/ContactAddPopup';
import ContactEditPopup from '../Popups/ContactEditPopup';
import ContactViewPopup from '../Popups/ContactViewPopup';
import DataManager from '../../Scripts/DataManagement';
import InnerAlert from '../Alerts/InnerAlert';

class Main extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            showAddPopup: false,  // Wether to show add popup or not
            popup: null,          // Takes a popup component
            alert: null,          // Tales an alert component that gets shown in the main section
            filterString: "",     // String to filter contacts list
            numberOfPeople: 0     // Number of people in the list
        }
    }

    /*======Popups Toggle======*/
    //Shows/Hides add popup
    toggleAddContactPopup() {
        this.setState({
            showAddPopup: !this.state.showAddPopup
        });
    }

    //Closes any popup component
    closePopup() {
        this.setState({
            popup: null
        });
    }
    /*======Popups Toggle======*/

    //Displays edit popup
    editContact(id) {
        let editPopup = <ContactEditPopup id={ id } closePopup={ this.closePopup.bind(this) } />;

        this.setState({
            popup: editPopup
        });
    }

    //Displays view contact popup
    viewContact(id) {
        let viewPopup = <ContactViewPopup id={ id } closePopup={ this.closePopup.bind(this) } />;

        this.setState({
            popup: viewPopup
        });
    }

    //Updates the filter string
    filterContacts(filterString) {
        this.setState({ filterString: filterString });
    }

    //Deletes all contacts after asking again
    deleteContacts() {
        if(window.confirm("Are you sure you want to delete all contacts?")) DataManager.deleteContacts();
    }

    //Interval variable to disable multiple alerts at the same time
    saveVar = null;
    saveContacts() {
        //save contacts data
        DataManager.saveContacts();
        //Don't show alert if there is no contacts
        if(this.state.numberOfPeople === 0) {
            alert("Data saved");
            return;
        }
        //if there is an interval the clear it
        if(this.saveVar) clearTimeout(this.saveVar);
        //show data saved text
        this.setState({ alert: <InnerAlert alert="Data saved" /> });
        //hide data saved text after 3 seconds
        this.saveVar = setTimeout((function() { 
            this.setState({ alert: null });
        }).bind(this), 3000);
    }

    //Updates number of people int the list
    contactsUpdate(count) {
        if(this.state.numberOfPeople !== count)
            this.setState({ numberOfPeople: count });
    }

    render() {
        return (
            <main>
                <section>
                    <div className="box">
                        {/*Note to show number of people*/}
                        <div className="note">{ this.state.numberOfPeople } people</div>
                        {/*box top bar*/}
                        <InnerHeader 
                            addBtnClick={ this.toggleAddContactPopup.bind(this) } 
                            deleteAllBtnClick={ this.deleteContacts } 
                            saveBtnClick={ this.saveContacts.bind(this) }
                            onSearch={ this.filterContacts.bind(this) } />
                        {/*Alerts*/}
                        { this.state.alert }
                        {/*Contacts section*/}
                        <ContactsList filterString={ this.state.filterString } onChange={ this.contactsUpdate.bind(this) } itemEditClick={ this.editContact.bind(this) } itemViewClick={ this.viewContact.bind(this) } />
                        {/*================Popups===============*/}
                        {/*Add Contact Popup*/}
                        { this.state.showAddPopup ? <ContactAddPopup closePopup={ this.toggleAddContactPopup.bind(this) } /> : null }
                        {/*Edit Contact Popup*/}
                        { this.state.popup }
                        {/*================Popups===============*/}
                    </div>
                </section>
            </main>
        );
    }

};

export default Main;
