import React from 'react';

const InnerAlert = props => {
  return (
      <div className="center">
          <h2>{props.alert}</h2>
      </div>
  );
};

InnerAlert.defaultProps = {
  "alert": "No contacts found"
};

export default InnerAlert;
