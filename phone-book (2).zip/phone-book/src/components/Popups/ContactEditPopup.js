import React from 'react';
import DataManager from '../../Scripts/DataManagement';
import TextField from '../TextField/TextField';

class ContactEditPopup extends React.Component {
    constructor(props) {
        super(props);
        const contactData = DataManager.getContact(props.id);
        this.state = {
            id: contactData.id,
            name: { value: contactData.name,  valid: true },
            phone: { value: contactData.phone,  valid: true },
            address: { value: contactData.address,  valid: true },
            age: { value: contactData.age,  valid: true },
            imgUrl: { value: contactData.imgUrl,  valid: true }
        };
        this.handleChange = this.handleChange.bind(this);
    }

    //Edit done clicked
    saveEdit() {
        if(this.state.name.valid && this.state.phone.valid && this.state.address.valid && this.state.age.valid && this.state.imgUrl.valid) {
            DataManager.updateContactData(this.state.id, this.state.name.value, this.state.phone.value, this.state.address.value, this.state.age.value, this.state.imgUrl.value);
            this.props.closePopup();
        }
    }

    //To handle input changes
    handleChange(event, valid) {
        const {name, value, type, checked} = event.target;
        type === "checkbox" ? this.setState({ [name]: checked }) : this.setState({ [name]: { value: value, valid: valid } });
    }

    render() {
        return (
            <div id="editContactPopup" className="overlay popup_overlay">
                <div className="popup box">
                    {/*Close popup button*/}
                    <a className="close-btn" onClick={ this.props.closePopup }>
                        <i className="fa fa-close"></i>
                    </a>
                    <h1 className="header">Edit Contant</h1>
                    <div className="content">
                        <TextField title="Name" required={ true } name="name" value={ this.state.name.value } onChange={ this.handleChange }
                            reg="^[a-zA-z\s]{3,16}$" invalidMes="Name must contain 3 - 16 character no numbers" />
                        <TextField title="Phone" required={ true } name="phone" value={ this.state.phone.value } onChange={ this.handleChange } 
                            reg="^[0-9]{3}-?[0-9]{7}$" invalidMes="Phone must be 10 numbers / template ddd-ddddddd" />
                        <TextField title="Address" required={ true } name="address" value={ this.state.address.value } onChange={ this.handleChange } 
                            reg="^[\s\S]{0,60}$" invalidMes="Max 60 characters" />
                        <TextField title="Age" required={ true } name="age" value={ this.state.age.value } onChange={ this.handleChange } 
                            reg="^[0-1]?[0-9]{1,2}$" invalidMes="Max 199" />
                        <TextField title="Image URL" required={ true } name="imgUrl" value={ this.state.imgUrl.value } onChange={ this.handleChange } 
                            reg="^https?:\/\/[a-zA-Z0-9]{1,100}.[\s\S]{1,100}$" invalidMes="Must start with ( http or https) and contain a dot" />
                    </div>
                    <div className="footer">
                        <button onClick={ this.saveEdit.bind(this) } >send</button>
                    </div>
                </div>
            </div>
        );
    }
}

export default ContactEditPopup;