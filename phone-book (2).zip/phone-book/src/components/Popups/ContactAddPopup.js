import React from 'react';
import DataManager, { Contact } from '../../Scripts/DataManagement';
import TextField from '../TextField/TextField';

class ContactAddPopup extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            name: { value: "",  valid: false },
            phone: { value: "",  valid: false },
            address: { value: "",  valid: true },
            age: { value: "",  valid: false },
            imgUrl: { value: "",  valid: false }
        };
        this.handleChange = this.handleChange.bind(this);
    }

    //Add Clicked
    add() {
        if(this.state.name.valid && this.state.phone.valid && this.state.address.valid && this.state.age.valid && this.state.imgUrl.valid) {
            DataManager.addContact(new Contact(this.state.name.value, this.state.phone.value, this.state.address.value, this.state.age.value, this.state.imgUrl.value));
            this.props.closePopup();
        }

        this.setState({ forceValidation: true });
    }

    //To handle input changes
    handleChange(event, valid) {
        const {name, value, type, checked} = event.target;
        type === "checkbox" ? this.setState({ [name]: checked }) : this.setState({ [name]: { value: value, valid: valid } });
    }

    render() {
        return (
            <div id="createNewContactPopup" className="overlay popup_overlay">
                <div className="popup box">
                    {/*Close popup button*/}
                    <a className="close-btn" onClick={ this.props.closePopup }>
                        <i className="fa fa-close"></i>
                    </a>
                    <h1 className="header">Create Contant</h1>
                    <div className="content">
                        <TextField title="Name" required={ true } name="name" value={ this.state.name.value } onChange={ this.handleChange }
                            reg="^[a-zA-z\s]{3,16}$" invalidMes="Name must contain 3 - 16 character no numbers" forceValidation={this.state.forceValidation} />
                        <TextField title="Phone" required={ true } name="phone" value={ this.state.phone.value } onChange={ this.handleChange } 
                            reg="^[0-9]{3}-?[0-9]{7}$" invalidMes="Phone must be 10 numbers / template ddd-ddddddd" forceValidation={this.state.forceValidation} />
                        <TextField title="Address" required={ false } name="address" value={ this.state.address.value } onChange={ this.handleChange } 
                            reg="^[\s\S]{0,60}$" invalidMes="Max 60 characters" forceValidation={this.state.forceValidation} />
                        <TextField title="Age" required={ true } name="age" value={ this.state.age.value } onChange={ this.handleChange } 
                            reg="^[0-1]?[0-9]{1,2}$" invalidMes="Max 199" forceValidation={this.state.forceValidation} />
                        <TextField title="Image URL" required={ true } name="imgUrl" value={ this.state.imgUrl.value } onChange={ this.handleChange } 
                            reg="^https?:\/\/[a-zA-Z0-9]{1,100}.[\s\S]{1,100}$" invalidMes="Must start with ( http or https) and contain a dot" forceValidation={this.state.forceValidation} />
                    </div>
                    <div  className="footer">
                        <button onClick={ this.add.bind(this) }>create</button>
                    </div>
                </div>
            </div>
        );
    }

}

export default ContactAddPopup;
