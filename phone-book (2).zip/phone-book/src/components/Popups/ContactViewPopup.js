import React from 'react';
import DataManager from '../../Scripts/DataManagement';

const ContactViewPopup = props => {
    const contactData = DataManager.getContact(props.id);

    return (
        <div id="viewContactPopup" className="overlay popup_overlay" onClick={ props.closePopup }>
            <div className="popup box">
                <h1 className="header">{ contactData.name }</h1>
                <div className="content">
                    <div>
                        <span>Telephone:</span>
                        <span>{ contactData.phone }</span>
                    </div>
                    <div>
                        <span>Address:</span>
                        <span>{ contactData.address }</span>
                    </div>
                    <div>
                        <span>Age:</span>
                        <span>{ contactData.age }</span>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ContactViewPopup;